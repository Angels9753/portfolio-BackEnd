package com.portfolio.cay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CayApplicationTests {

	@Test
	void contextLoads() {
	}

}

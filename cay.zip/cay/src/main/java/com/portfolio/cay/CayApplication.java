package com.portfolio.cay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CayApplication.class, args);
	}

}
